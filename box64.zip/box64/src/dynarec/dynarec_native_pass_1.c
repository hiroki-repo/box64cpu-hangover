#define STEP 1
#include "dynarec_native_pass.c"
