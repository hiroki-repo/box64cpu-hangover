#define STEP 0
#include "dynarec_native_pass.c"
